import React from "react";

function Heading() {
  return (
    <div className="judul">
      <h1>emojipedia</h1>
    </div>
  );
}

export default Heading;
